// Preload script for Benedictaitor Test Runner
// This script will be loaded before the renderer process

window.addEventListener('DOMContentLoaded', () => {
  // You can add initialization code that needs to run before the main renderer script
  console.log('Preload script executed');
});